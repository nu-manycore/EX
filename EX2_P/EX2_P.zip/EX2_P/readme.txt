EX2 for Python

Caution: EX2 for Python seems more difficult than C version because Python does not have a good thread library like OpenMP.

1. Run thread_sample.py on your machine.  Sometimes Thread is not faster than Sequential due to Python GIL.
   In that case, you need to implement with Process.

2. Revise primes.py into thread programming as explained at the 2nd class, and show scalability.
